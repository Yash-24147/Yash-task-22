
const menuBtn = document.getElementById("menuBtn");
const menu = document.getElementById("menu");

menuBtn.addEventListener("click", function () {
    menu.classList.toggle("hidden");
});

const chatBtn = document.getElementById("chatBtn");
const chatBox = document.getElementById("chatBox");
const closeChat = document.getElementById("closeChat");

chatBtn.addEventListener("click", function () {
    chatBox.classList.toggle("hidden");
});

closeChat.addEventListener("click", function () {
    chatBox.classList.add("hidden");
});
